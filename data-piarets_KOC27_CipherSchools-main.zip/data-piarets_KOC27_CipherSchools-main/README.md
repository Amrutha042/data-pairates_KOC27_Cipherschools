# data-piarets_KOC27_CipherSchools
This Python project is about whether the matrix which is input by the user is magic square or not.
